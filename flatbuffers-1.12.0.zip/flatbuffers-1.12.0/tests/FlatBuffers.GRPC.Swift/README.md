# FlatBuffers.GRPC.Swift

The following is Swift example on how GRPC would be with Swift Flatbuffers
